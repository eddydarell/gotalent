import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { logger } from 'hono/logger';
import { Database } from '@db/sqlite';

interface FormData {
  nom: string;
  postNom?: string;
  prenom?: string;
  sexe: string;
  dateNaissance?: string;
  email: string;
  telephone?: string;
  adresse?: string;
  diplome: string;
  etablissement: string;
  anneeObtention: number;
  poste: string;
  entreprise?: string;
  anneesExperience?: number;
  descriptionPoste?: string;
  commentEntendu: string[];
  attentes: string[];
  commentairesSupplementaires?: string;
  accepteTermes: boolean;
  accepteUtilisationDonnees: boolean;
  souhaiteInformationsFutures: boolean;
}

const app = new Hono();

// Middleware
app.use('*', logger());
app.use('*', cors({
  origin: ['http://localhost:5173', 'http://localhost:3000'],
  credentials: true,
}));

// Database connection
const db = new Database('inscriptions.db');

// Validation function
function validateFormData(data: any): string[] {
  const errors: string[] = [];

  if (!data.nom?.trim()) errors.push('Le nom est requis');
  if (!data.sexe?.trim()) errors.push('Le sexe est requis');
  if (!data.email?.trim()) errors.push('L\'email est requis');
  if (data.email && !/\S+@\S+\.\S+/.test(data.email)) {
    errors.push('Format d\'email invalide');
  }
  if (!data.diplome?.trim()) errors.push('Le diplôme est requis');
  if (!data.etablissement?.trim()) errors.push('L\'établissement est requis');
  if (!data.anneeObtention) errors.push('L\'année d\'obtention est requise');
  if (!data.poste?.trim()) errors.push('Le poste est requis');
  if (!Array.isArray(data.commentEntendu) || data.commentEntendu.length === 0) {
    errors.push('Veuillez sélectionner comment vous avez entendu parler de l\'événement');
  }
  if (!Array.isArray(data.attentes) || data.attentes.length === 0) {
    errors.push('Veuillez sélectionner vos attentes');
  }
  if (!data.accepteTermes) {
    errors.push('Vous devez accepter les termes et conditions');
  }
  if (!data.accepteUtilisationDonnees) {
    errors.push('Vous devez accepter l\'utilisation de vos données');
  }

  return errors;
}

// Routes

// Health check
app.get('/api/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Get all inscriptions (for admin purposes)
app.get('/api/inscriptions', (c) => {
  try {
    const inscriptions = db.prepare(`
      SELECT 
        id, nom, post_nom, prenom, sexe, date_naissance, email, telephone, adresse,
        diplome, etablissement, annee_obtention, poste, entreprise, annees_experience,
        description_poste, comment_entendu, attentes, commentaires_supplementaires,
        accepte_termes, accepte_utilisation_donnees, souhaite_informations_futures,
        created_at, updated_at
      FROM inscriptions 
      ORDER BY created_at DESC
    `).all();

    // Parse JSON fields
    const formattedInscriptions = inscriptions.map((inscription) => ({
      ...inscription,
      comment_entendu: JSON.parse(inscription.comment_entendu || '[]'),
      attentes: JSON.parse(inscription.attentes || '[]'),
    }));

    return c.json({
      success: true,
      data: formattedInscriptions,
      count: formattedInscriptions.length
    });
  } catch (error) {
    console.error('Error fetching inscriptions:', error);
    return c.json({
      success: false,
      message: 'Erreur lors de la récupération des inscriptions'
    }, 500);
  }
});

// Create new inscription
app.post('/api/inscriptions', async (c) => {
  try {
    const data: FormData = await c.req.json();
    
    // Validate data
    const errors = validateFormData(data);
    if (errors.length > 0) {
      return c.json({
        success: false,
        message: 'Erreurs de validation',
        errors
      }, 400);
    }

    // Check if email already exists
    const existingInscription = db.prepare(
      'SELECT id FROM inscriptions WHERE email = ?'
    ).get(data.email);

    if (existingInscription) {
      return c.json({
        success: false,
        message: 'Cette adresse email est déjà utilisée pour une inscription'
      }, 409);
    }

    // Insert new inscription
    const stmt = db.prepare(`
      INSERT INTO inscriptions (
        nom, post_nom, prenom, sexe, date_naissance, email, telephone, adresse,
        diplome, etablissement, annee_obtention, poste, entreprise, annees_experience,
        description_poste, comment_entendu, attentes, commentaires_supplementaires,
        accepte_termes, accepte_utilisation_donnees, souhaite_informations_futures
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const result = stmt.run(
      data.nom,
      data.postNom || null,
      data.prenom || null,
      data.sexe,
      data.dateNaissance || null,
      data.email,
      data.telephone || null,
      data.adresse || null,
      data.diplome,
      data.etablissement,
      data.anneeObtention,
      data.poste,
      data.entreprise || null,
      data.anneesExperience || null,
      data.descriptionPoste || null,
      JSON.stringify(data.commentEntendu),
      JSON.stringify(data.attentes),
      data.commentairesSupplementaires || null,
      data.accepteTermes ? 1 : 0,
      data.accepteUtilisationDonnees ? 1 : 0,
      data.souhaiteInformationsFutures ? 1 : 0
    );

    return c.json({
      success: true,
      message: 'Inscription enregistrée avec succès!',
      data: { id: result }
    }, 201);

  } catch (error) {
    console.error('Error creating inscription:', error);
    return c.json({
      success: false,
      message: 'Erreur lors de l\'enregistrement de l\'inscription'
    }, 500);
  }
});

// Get inscription by ID
app.get('/api/inscriptions/:id', (c) => {
  try {
    const id = c.req.param('id');
    const inscription = db.prepare(`
      SELECT 
        id, nom, post_nom, prenom, sexe, date_naissance, email, telephone, adresse,
        diplome, etablissement, annee_obtention, poste, entreprise, annees_experience,
        description_poste, comment_entendu, attentes, commentaires_supplementaires,
        accepte_termes, accepte_utilisation_donnees, souhaite_informations_futures,
        created_at, updated_at
      FROM inscriptions 
      WHERE id = ?
    `).get(id);

    if (!inscription) {
      return c.json({
        success: false,
        message: 'Inscription non trouvée'
      }, 404);
    }

    // Parse JSON fields - inscription is an object with string properties
    const inscriptionObj = inscription as Record<string, string | number>;
    const formattedInscription = {
      ...inscriptionObj,
      comment_entendu: JSON.parse(String(inscriptionObj.comment_entendu) || '[]'),
      attentes: JSON.parse(String(inscriptionObj.attentes) || '[]'),
    };

    return c.json({
      success: true,
      data: formattedInscription
    });
  } catch (error) {
    console.error('Error fetching inscription:', error);
    return c.json({
      success: false,
      message: 'Erreur lors de la récupération de l\'inscription'
    }, 500);
  }
});

// Statistics endpoint
app.get('/api/statistics', (c) => {
  try {
    const totalInscriptions = db.prepare('SELECT COUNT(*) as count FROM inscriptions').get();
    
    const sexeStats = db.prepare(`
      SELECT sexe, COUNT(*) as count 
      FROM inscriptions 
      GROUP BY sexe
    `).all();

    return c.json({
      success: true,
      data: {
        total: totalInscriptions?.count || 0,
        sexe: sexeStats
      }
    });
  } catch (error) {
    console.error('Error fetching statistics:', error);
    return c.json({
      success: false,
      message: 'Erreur lors de la récupération des statistiques'
    }, 500);
  }
});

// Error handling
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({
    success: false,
    message: 'Erreur interne du serveur'
  }, 500);
});

// 404 handler
app.notFound((c) => {
  return c.json({
    success: false,
    message: 'Endpoint non trouvé'
  }, 404);
});

// Graceful shutdown
const shutdown = () => {
  console.log('Closing database connection...');
  db.close();
  Deno.exit(0);
};

Deno.addSignalListener('SIGINT', shutdown);
Deno.addSignalListener('SIGTERM', shutdown);

const port = Number(Deno.env.get('PORT')) || 8000;

console.log(`Server running on http://localhost:${port}`);
Deno.serve({ port }, app.fetch);
