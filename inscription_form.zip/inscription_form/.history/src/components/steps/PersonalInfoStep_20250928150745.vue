<template>
  <div class="pa-4 step-container">
    <v-card-title class="text-h5 mb-4 step-title">
      <v-icon icon="mdi-account" class="mr-3 step-icon" />
      Informations personnelles
    </v-card-title>
    
    <v-row>
      <v-col cols="12" md="6">
        <v-text-field
          v-model="formData.nom"
          label="Nom *"
          placeholder="Votre nom de famille"
          :error-messages="errors.nom"
          required
          variant="outlined"
          prepend-inner-icon="mdi-account"
          @input="updateField('nom', $event.target.value)"
        />
      </v-col>
      
      <v-col cols="12" md="6">
        <v-text-field
          v-model="formData.postNom"
          label="Post-nom"
          placeholder="Votre post-nom"
          variant="outlined"
          prepend-inner-icon="mdi-account"
          @input="updateField('postNom', $event.target.value)"
        />
      </v-col>
      
      <v-col cols="12" md="6">
        <v-text-field
          v-model="formData.prenom"
          label="Prénom"
          placeholder="Votre prénom"
          variant="outlined"
          prepend-inner-icon="mdi-account"
          @input="updateField('prenom', $event.target.value)"
        />
      </v-col>
      
      <v-col cols="12" md="6">
        <v-select
          v-model="formData.sexe"
          label="Sexe *"
          :items="sexeOptions"
          :error-messages="errors.sexe"
          required
          variant="outlined"
          prepend-inner-icon="mdi-gender-male-female"
          @update:model-value="updateField('sexe', $event)"
        />
      </v-col>
      
      <v-col cols="12" md="6">
        <v-text-field
          v-model="formData.dateNaissance"
          label="Date de naissance"
          type="date"
          variant="outlined"
          prepend-inner-icon="mdi-calendar"
          @input="updateField('dateNaissance', $event.target.value)"
        />
      </v-col>
      
      <v-col cols="12" md="6">
        <v-text-field
          v-model="formData.email"
          label="Email *"
          type="email"
          placeholder="votre.email@exemple.com"
          :error-messages="errors.email"
          required
          variant="outlined"
          prepend-inner-icon="mdi-email"
          @input="updateField('email', $event.target.value)"
        />
      </v-col>
      
      <v-col cols="12" md="6">
        <v-text-field
          v-model="formData.telephone"
          label="Téléphone"
          type="tel"
          placeholder="+243 XXX XXX XXX"
          variant="outlined"
          prepend-inner-icon="mdi-phone"
          @input="updateField('telephone', $event.target.value)"
        />
      </v-col>
      
      <v-col cols="12" md="6">
        <v-textarea
          v-model="formData.adresse"
          label="Adresse"
          placeholder="Votre adresse complète"
          rows="3"
          variant="outlined"
          prepend-inner-icon="mdi-map-marker"
          @input="updateField('adresse', $event.target.value)"
        />
      </v-col>
    </v-row>
    
    <v-alert
      type="info"
      variant="tonal"
      class="mt-4"
    >
      Les champs marqués d'un astérisque (*) sont obligatoires.
    </v-alert>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useFormStore } from '@/stores/form'

const formStore = useFormStore()

const formData = computed(() => formStore.formData)
const errors = computed(() => formStore.errors)

const sexeOptions = [
  { title: 'Masculin', value: 'Masculin' },
  { title: 'Féminin', value: 'Féminin' },
  { title: 'Autre', value: 'Autre' },
  { title: 'Préfère ne pas dire', value: 'Préfère ne pas dire' }
]

const updateField = (field: string, value: any) => {
  formStore.updateFormData(field as any, value)
  formStore.clearError(field)
}
</script>
