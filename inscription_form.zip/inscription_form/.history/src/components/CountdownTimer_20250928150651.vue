<template>
  <v-card-text class="text-center pa-4 countdown-container" :class="countdownClass">
    <div class="countdown-title text-subtitle-1 mb-3">
      <v-icon :icon="isUrgent ? 'mdi-clock-alert' : 'mdi-clock-outline'" class="mr-2 countdown-icon" />
      {{ isExpired ? 'Délai d\'inscription expiré' : 'Temps restant pour s\'inscrire' }}
    </div>
    
    <div v-if="!isExpired" class="d-flex justify-center align-center countdown-display">
      <div class="mx-2 text-center countdown-unit">
        <div class="countdown-number-box">
          <div class="countdown-number">
            <transition name="roll" mode="out-in">
              <span :key="timeLeft.days">{{ timeLeft.days }}</span>
            </transition>
          </div>
        </div>
        <div class="countdown-label">Jours</div>
      </div>
      
      <div class="countdown-separator">:</div>
      
      <div class="mx-2 text-center countdown-unit">
        <div class="countdown-number-box">
          <div class="countdown-number">
            <transition name="roll" mode="out-in">
              <span :key="timeLeft.hours">{{ timeLeft.hours }}</span>
            </transition>
          </div>
        </div>
        <div class="countdown-label">Heures</div>
      </div>
      
      <div class="countdown-separator">:</div>
      
      <div class="mx-2 text-center countdown-unit">
        <div class="countdown-number-box">
          <div class="countdown-number">
            <transition name="roll" mode="out-in">
              <span :key="timeLeft.minutes">{{ timeLeft.minutes }}</span>
            </transition>
          </div>
        </div>
        <div class="countdown-label">Minutes</div>
      </div>
      
      <div class="countdown-separator">:</div>
      
      <div class="mx-2 text-center countdown-unit">
        <div class="countdown-number-box">
          <div class="countdown-number">
            <transition name="roll" mode="out-in">
              <span :key="timeLeft.seconds">{{ timeLeft.seconds }}</span>
            </transition>
          </div>
        </div>
        <div class="countdown-label">Secondes</div>
      </div>
    </div>
    
    <div v-else class="text-h6 expired-message">
      <v-icon icon="mdi-alert-circle" class="mr-2" />
      L'inscription n'est plus possible
    </div>
  </v-card-text>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'

interface Props {
  deadline: Date
}

const props = defineProps<Props>()

const now = ref(new Date())
let interval: NodeJS.Timeout | null = null

const timeLeft = computed(() => {
  const diff = props.deadline.getTime() - now.value.getTime()
  
  if (diff <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0 }
  }
  
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
  const seconds = Math.floor((diff % (1000 * 60)) / 1000)
  
  return {
    days: days.toString().padStart(2, '0'),
    hours: hours.toString().padStart(2, '0'),
    minutes: minutes.toString().padStart(2, '0'),
    seconds: seconds.toString().padStart(2, '0')
  }
})

const isExpired = computed(() => {
  return props.deadline.getTime() <= now.value.getTime()
})

const isUrgent = computed(() => {
  const diff = props.deadline.getTime() - now.value.getTime()
  const threeDaysInMs = 3 * 24 * 60 * 60 * 1000
  return diff <= threeDaysInMs && diff > 0
})

onMounted(() => {
  interval = setInterval(() => {
    now.value = new Date()
  }, 1000)
})

onUnmounted(() => {
  if (interval) {
    clearInterval(interval)
  }
})
</script>

<style scoped>
.countdown-number {
  position: relative;
  overflow: hidden;
  height: 1.5em;
  display: flex;
  align-items: center;
  justify-content: center;
}

.roll-enter-active,
.roll-leave-active {
  transition: all 0.3s ease;
}

.roll-enter-from {
  transform: translateY(-20%);
  opacity: 0;
}

.roll-leave-to {
  transform: translateY(20%);
  opacity: 0;
}

.roll-enter-to,
.roll-leave-from {
  transform: translateY(0);
  opacity: 1;
}
</style>
