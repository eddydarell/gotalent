import { createApp } from 'vue'
import App from './App.vue'
import { createVuetify } from 'vuetify'
import { createPinia } from 'pinia'
import 'vuetify/styles'
import '@mdi/font/css/materialdesignicons.css'

const vuetify = createVuetify({
  theme: {
    defaultTheme: 'light',
    themes: {
      light: {
        colors: {
          primary: '#B8860B', // Dark golden rod
          secondary: '#2C1810', // Dark brown for text
          accent: '#FFD700', // Bright gold
          error: '#D32F2F',
          info: '#CD853F', // Peru gold
          success: '#B8860B', // Dark golden rod
          warning: '#FF8F00',
          surface: '#FFFEF7', // Warm white
          background: '#FFF8E1', // Light golden background
          'on-primary': '#FFFFFF',
          'on-secondary': '#FFFFFF',
          'on-surface': '#2C1810',
          'on-background': '#2C1810',
        },
      },
      dark: {
        colors: {
          primary: '#FFD700', // Bright gold for dark theme
          secondary: '#F5F5DC', // Beige for text
          accent: '#FFA000', // Amber accent
          error: '#F44336',
          info: '#DAA520', // Golden rod
          success: '#FFD700', // Gold
          warning: '#FF9800',
          surface: '#1A1611', // Dark golden brown
          background: '#0D0A08', // Very dark brown
          'on-primary': '#1A1611',
          'on-secondary': '#1A1611',
          'on-surface': '#F5F5DC',
          'on-background': '#F5F5DC',
        },
      },
    },
  },
  icons: {
    defaultSet: 'mdi',
  },
})

const pinia = createPinia()

createApp(App).use(vuetify).use(pinia).mount('#app')
