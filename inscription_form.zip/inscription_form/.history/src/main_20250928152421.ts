import { createApp } from 'vue'
import App from './App.vue'
import { createVuetify } from 'vuetify'
import { createPinia } from 'pinia'
import 'vuetify/styles'
import '@mdi/font/css/materialdesignicons.css'

const vuetify = createVuetify({
  theme: {
    defaultTheme: 'light',
    themes: {
      light: {
        colors: {
          background: '#FAF9F6',   // soft off-white
    surface: '#FFFFFF',      // pure white for cards
    primary: '#C8A150',      // golden-brown accent
    'primary-darken-1': '#A8823B',
    secondary: '#2A201C',    // deep brown
    'secondary-darken-1': '#1A1411',
    accent: '#E2B65D',       // bright gold highlight
    error: '#D93025',
    info: '#3B82F6',
    success: '#16A34A',
          warning: '#F59E0B',
          'on-primary': '#FFFFFF',
          'on-secondary': '#FFFFFF',
          'on-surface': '#2A201C',
          'on-background': '#2A201C',
        },
        dark: false,
      },
      dark: {
      colors: {
    background: '#1A1411',   // dark brown-black
    surface: '#2A201C',      // rich dark chocolate
    primary: '#E2B65D',      // golden highlight
    'primary-darken-1': '#C8A150',
    secondary: '#E6D9C8',    // beige for text
    'secondary-darken-1': '#B68A6E',
    accent: '#FFD67C',       // brighter gold for emphasis
    error: '#F87171',
    info: '#60A5FA',
    success: '#4ADE80',
          warning: '#FBBF24',
          'on-primary': '#1A1411',
          'on-secondary': '#1A1411',
          'on-surface': '#E6D9C8',
          'on-background': '#E6D9C8',
        },
        dark: true,
  }
      }
      // light: {
      //   colors: {
      //     primary: '#B8860B', // Dark golden rod
      //     secondary: '#2C1810', // Dark brown for text
      //     accent: '#FFD700', // Bright gold
      //     error: '#D32F2F',
      //     info: '#CD853F', // Peru gold
      //     success: '#B8860B', // Dark golden rod
      //     warning: '#FF8F00',
      //     surface: '#FFFEF7', // Warm white
      //     background: '#FFF8E1', // Light golden background
      //     'on-primary': '#FFFFFF',
      //     'on-secondary': '#FFFFFF',
      //     'on-surface': '#2C1810',
      //     'on-background': '#2C1810',
      //   },
      // },
      // dark: {
      //   colors: {
      //     primary: '#FFD700', // Bright gold for dark theme
      //     secondary: '#F5F5DC', // Beige for text
      //     accent: '#FFA000', // Amber accent
      //     error: '#F44336',
      //     info: '#DAA520', // Golden rod
      //     success: '#FFD700', // Gold
      //     warning: '#FF9800',
      //     surface: '#1A1611', // Dark golden brown
      //     background: '#0D0A08', // Very dark brown
      //     'on-primary': '#1A1611',
      //     'on-secondary': '#1A1611',
      //     'on-surface': '#F5F5DC',
      //     'on-background': '#F5F5DC',
      //   },
      // },
    // },
  },
  icons: {
    defaultSet: 'mdi',
  },
})

const pinia = createPinia()

createApp(App).use(vuetify).use(pinia).mount('#app')
